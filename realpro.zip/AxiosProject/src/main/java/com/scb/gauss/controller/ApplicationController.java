package com.scb.gauss.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.bean.Application;
import com.scb.gauss.service.ApplicationService;


@RestController
@RequestMapping("/application")
public class ApplicationController {

	
	@Autowired
	private ApplicationService appService;
	
	static
	{
		System.out.println("In Controller");
	}

	/* Adding a resource */
	@PostMapping("/add")
	private int add(@RequestBody Application Application) {
		
		return appService.add(Application);
	}
	@GetMapping("/getAll")
	private Collection<Application> list() {
		System.out.println("getall");
		return appService.list();
	}
}
