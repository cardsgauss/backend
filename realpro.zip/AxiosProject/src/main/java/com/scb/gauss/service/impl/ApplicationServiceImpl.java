package com.scb.gauss.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.Application;
import com.scb.gauss.dao.ApplicationDAO;

@Service
public class ApplicationServiceImpl {
	@Autowired
	private ApplicationDAO appDAO;
	
	static
	{
		System.out.println("In Service");
	}

	public int add(Application application) {
		return appDAO.add(application);
	}
	
	public List<Application> list() {
		return appDAO.list();
	}
 
}
