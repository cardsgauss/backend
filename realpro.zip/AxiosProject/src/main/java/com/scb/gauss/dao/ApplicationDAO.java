package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Application;

public interface ApplicationDAO {
	public int add(Application application);
	public List<Application> list();
}
