package com.scb.gauss.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.Application;


//import com.scb.gauss.dao.Impl.ApplicationDAOImpl.ApplicationMapper;
@Repository
public class ApplicationDAOimpl {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	static
	{
		System.out.println("In dao");
	}

public int add(Application application) 
	{
	
	String query = "INSERT INTO applications(app_name,app_status,application_age,handled_by,cust_id) VALUES(?,?,?,?,?)";
	return jdbcTemplate.update(query, new Object[]{application.getAppName(),
			 application.getStatus(),application.getAge(),application.getHandledBy(),application.getCust_id()
	});
	}

	public List<Application> list() {
		String query = "SELECT * FROM applications";
		return jdbcTemplate.query(query, new ApplicationMapper());

	}
	class ApplicationMapper implements RowMapper<Application> {

		
		public Application mapRow(ResultSet rs, int rowNum) throws SQLException {
			Application application = new Application();
			
			application.setCust_id(rs.getInt("cust_id"));
			application.setAppName(rs.getString("name"));
			application.setStatus(rs.getString("status"));
			application.setHandledBy(rs.getString("handled_by"));
			application.setAge(rs.getInt("age"));
			return application;
		}

	}
}
