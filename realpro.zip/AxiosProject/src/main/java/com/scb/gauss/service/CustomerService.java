package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.Customer;




public interface CustomerService {
	public int add(Customer customer);
	public List<Customer> list();
	}
