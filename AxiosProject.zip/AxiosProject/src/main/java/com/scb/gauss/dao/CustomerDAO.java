package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Customer;






public interface CustomerDAO {
	public int add(Customer customer);
	public List<Customer> list();
			
}