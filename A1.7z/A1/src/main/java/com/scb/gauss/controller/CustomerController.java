package com.scb.gauss.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.scb.gauss.bean.CardsCustomer;
import com.scb.gauss.bean.Charts;
import com.scb.gauss.service.ApplicationService;
import com.scb.gauss.service.CustomerService;


@RestController
@RequestMapping("customer")
public class CustomerController {

	@Autowired
	private CustomerService custService;
	
	@Autowired
	private ApplicationService appService;
	
	static
	{
		System.out.println("In Controller");
	}

	/* Adding a resource */
	@PostMapping("/add")
	private int add(@RequestBody CardsCustomer customer) {
		
		return custService.add(customer);
	}
	@GetMapping("/")
	private Collection<CardsCustomer> list() {
		return custService.list();
	}
	@DeleteMapping("delete/{id}")
	private int delete(@PathVariable int id) {
		return custService.delete(id);
	}
	@GetMapping("/{id}")
	private CardsCustomer get(@PathVariable int id) {
		return custService.get(id);
	}
	@PutMapping("/update")
	private int update(@RequestBody CardsCustomer customer) {
		return custService.update(customer);
	}
	@PutMapping("/appeal")
	private int appeal(@RequestBody CardsCustomer customer) {
		return custService.appeal(customer);
	}
//	@PutMapping("/status")
//	private void status(@RequestBody Customer customer) {
//		 custService.update(customer);
//	
//	
//    @GetMapping("/{aadhar}")
//    private void isaadhar(@RequestBody int aadhar) {
//          custService.isaadhar(aadhar);
//    }
	@GetMapping("/aadhaar/{aadhar}")
	private int isaadhar(@PathVariable long aadhar) {
		 return custService.isaadhar(aadhar);
	}
	
	@PutMapping("/appealstatus")
	private void appealstatus(@RequestBody CardsCustomer c) {
		 custService.appealStatus(c);
	}
	
	@PutMapping("/docstatus")
	private void docstatus(@RequestBody CardsCustomer c) {
		 custService.docStatus(c);
	}
	
	
	@PutMapping("/agestatus")
	private void agestatus(@RequestBody CardsCustomer c)
	{
	     custService.ageStatus(c);	
	}
	
	@GetMapping("/charts")
	private List<Charts> pie()
	{
		return custService.chart();
	}
	

	}
