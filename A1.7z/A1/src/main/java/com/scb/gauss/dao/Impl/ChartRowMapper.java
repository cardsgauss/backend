package com.scb.gauss.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.scb.gauss.bean.Charts;

public class ChartRowMapper implements RowMapper<Charts> {

	public Charts mapRow(ResultSet rs,int rowNum) throws SQLException
	{
		Charts c=new Charts();
		c.setCount(rs.getInt(1));
		c.setStatus(rs.getString(2));
		return c;
	}
	
}
