package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.CardsCustomer;
import com.scb.gauss.bean.Charts;


public interface CustomerService {
	public int add(CardsCustomer customer);
	public List<CardsCustomer> list();
	public int delete(int id);
	public CardsCustomer get(int id);
	public int update(CardsCustomer customer);
	public int appeal(CardsCustomer customer);
//	public void status(Customer c);
	public int isaadhar(long a);
	public void docStatus(CardsCustomer c);
	public void appealStatus(CardsCustomer c);
	public void ageStatus(CardsCustomer c);
	public List<Charts> chart();

	}
