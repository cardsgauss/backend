package com.scb.gauss.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.gauss.bean.Appeal;

import com.scb.gauss.dao.AppealDAO;

import com.scb.gauss.service.AppealService;


@Service
public class AppealServiceImpl implements AppealService{
	@Autowired
	private AppealDAO appealDAO;
@Override
	public List<Appeal> list()
	{
		return appealDAO.list();
	}
	
}

