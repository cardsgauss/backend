package com.scb.gauss.dao;

import java.util.List;

import com.scb.gauss.bean.Appeal;


public interface AppealDAO {
	public List<Appeal> list();
}
