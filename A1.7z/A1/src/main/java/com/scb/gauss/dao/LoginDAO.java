package com.scb.gauss.dao;

import com.scb.gauss.bean.Login;

public interface LoginDAO {
  public String login(Login a);
  public int create(Login a);
}
