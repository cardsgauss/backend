package com.scb.gauss.service;

import java.util.List;

import com.scb.gauss.bean.Product;



public interface ProductService {
	public List<Product> list();
}
