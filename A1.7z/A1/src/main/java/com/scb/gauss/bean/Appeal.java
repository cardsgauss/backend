package com.scb.gauss.bean;

public class Appeal {
private int id;
private String name;
private String reason;
private int score;
private String status;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getReason() {
	return reason;
}
public void setReason(String reason) {
	this.reason = reason;
}
public int getScore() {
	return score;
}
public void setScore(int score) {
	this.score = score;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public Appeal(int id, String name, String reason, int score, String status) {
	super();
	this.id = id;
	this.name = name;
	this.reason = reason;
	this.score = score;
	this.status = status;
}
public Appeal() {
	super();
}

}
