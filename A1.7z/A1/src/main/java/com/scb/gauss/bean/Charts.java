package com.scb.gauss.bean;

public class Charts {
 public String status="";
 public int count;
public Charts(String status, int count) {
	super();
	this.status = status;
	this.count = count;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public int getCount() {
	return count;
}
public void setCount(int count) {
	this.count = count;
}
public Charts() {
	super();
}
@Override
public String toString() {
	return "Charts [status=" + status + ", count=" + count + "]";
}

 
 
}
