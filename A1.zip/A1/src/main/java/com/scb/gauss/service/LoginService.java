package com.scb.gauss.service;

import com.scb.gauss.bean.Login;

public interface LoginService {
    public int verify(Login a);
    
    
}
