package com.scb.gauss.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.Login;
import com.scb.gauss.dao.LoginDAO;
import com.scb.gauss.service.LoginService;

@Repository
public class LoginServiceimpl implements LoginService {

	
	@Autowired
	private LoginDAO logindao;
	
	
	@Override
	public String verify(Login a) {
	 return	logindao.login(a);
						
		
	}


	@Override
	public int create(Login a) {
		// TODO Auto-generated method stub
		 return	logindao.create(a);
	}
	
	
	
	
	
	
  
}
