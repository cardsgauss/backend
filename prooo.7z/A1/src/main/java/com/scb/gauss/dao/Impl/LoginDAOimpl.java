package com.scb.gauss.dao.Impl;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.scb.gauss.bean.Login;
import com.scb.gauss.dao.LoginDAO;

@Repository
public class LoginDAOimpl implements LoginDAO{

	
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	

	class Usermapper implements RowMapper<Login>
	{
	@Override
	public Login mapRow(ResultSet rs, int rowNum) throws SQLException {
		Login user = new Login();
		
		user.setUsername(rs.getString("username"));
		user.setPassword(rs.getString("password"));			
		return user;
	}
	}
	
	@Override
	public String login(Login a) {
		// TODO Auto-generated method stub
		String query = "SELECT role FROM login WHERE username=? AND password=?";
		try {
			Encryption e=new Encryption();
			String pass=e.getMd5(a.getPassword());
			//String role=jdbcTemplate.queryForObject(query, new Object[] { a.getUsername(),pass }, new Usermapper());
			String role=jdbcTemplate.queryForObject(query, new Object[] {a.getUsername(),pass },String.class);
		
			System.out.println(role);
			return role;
			
		} catch (EmptyResultDataAccessException e) {
			
			e.printStackTrace();
			return "error";
		}
		
		
	}

	@Override
	public int create(Login a) {
		// TODO Auto-generated method stub
		String query = "Insert into login(username,password) values(?,?)";
		try {
			Encryption e=new Encryption();
			String pass=e.getMd5(a.getPassword());
			jdbcTemplate.queryForObject(query, new Object[] { a.getUsername(),pass }, new Usermapper());
			
				
			return 1;
		} catch (Exception e) {
			
			e.printStackTrace();
			return 0;
		}

	}
	
}
